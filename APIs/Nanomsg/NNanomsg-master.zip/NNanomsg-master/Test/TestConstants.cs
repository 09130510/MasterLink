﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Test
{
    public static class TestConstants
    {
        public const int 
            Iterations = 10000,
            DataSize = 4 * 1024;//1024 * 100;

    }
}
