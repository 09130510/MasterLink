﻿namespace NNanomsg
{
    public struct NanomsgEndpoint
    {
        public int ID;
    }
}
