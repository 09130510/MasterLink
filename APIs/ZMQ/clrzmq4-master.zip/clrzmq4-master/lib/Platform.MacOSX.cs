﻿namespace ZeroMQ.lib
{

	public static partial class Platform
	{
		public static class MacOSX
		{

			public const string LibraryFileExtension = ".dylib";

		}
	}
}