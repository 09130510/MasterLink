﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FixInitiator.Class
{
    class Match    //成交回報 
    {
    }
}
